const home = async (req, res) => {

    try {
        res.status(200).send("Welcome Kushagra Ji");

    }

    catch (error) {
        console.log(error);
    }

}

const registration = async (req, res) => {

    try {
        res.status(200).send("Register Yourself ");
    

    }

    catch (error) {
        console.log(error);
    }

}

const all = async (req, res) => {

    try {
        res.status(200).send("Page Not Found 404");

    }

    catch (error) {
        console.log(error);
    }

}


module.exports = { home, registration, all };
