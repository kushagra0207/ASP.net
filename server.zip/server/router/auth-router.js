const express = require('express')

const router = express.Router(); // its a class present in the express. It allows to right route in other files.

const authcontrollers = require('../controllers/auth-controller');

router.route('/').get(authcontrollers.home);
router.route('/registration').get(authcontrollers.registration);
router.route('*').get(authcontrollers.all);



router.get('*',(req,res)=>{
    res.status(200).send("Page Not found 404");
    
});


module.exports = router;